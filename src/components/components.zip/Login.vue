<template>
  <div id='login'>
    <div id='naver_id_login' ref="naveridlogin"></div>
    <div id="address"></div>
  </div>
</template>
<script>
/* eslint-disable */

import './methods'
import { naver_id_login } from './naverLogin_implicit-1.0.3'
import { getUser } from './DBmethods'
import {getBT} from './bluetooth'
// import { getnaveruser } from './navermethods'

export default {
  name: 'Login',
  components: {
  },
  data: function () {
    return {
      show: 0,
      getUserResult: []
    }
  },
  created () {
    // console.log(ma)
  },
  methods: {
    onNext () {
      this.$router.push('/Start')
    }
  },
  mounted () {
    this.address = getBT()
    // this.getUserData = "{ 'btMac' : '" + getBT()[0].address + "' }" 
    // getUser("{ 'btMac' : '08:AE:D6:98:F7:90' }")
    //document.getElementById('address').innerHTML = getBT()[0].address


    var naveridlogin = new naver_id_login('TS7adrjF9NQUxlAOxEpk', 'http://localhost:8080')

    if(!naveridlogin.oauthParams.access_token){
      var state = naveridlogin.getUniqState();
      naveridlogin.setButton("green", 2,40);
      naveridlogin.setDomain("http://localhost:8080");
      // naveridlogin.setPopup();
      naveridlogin.setState(state);
      naveridlogin.init_naver_id_login(this.$refs.naveridlogin);
      // alert('11')
    }
    else{
      // alert(naveridlogin.oauthParams.access_token)
      alert('22')
      this.$router.push('/Start')
    }
  }
}
</script>

<style lang="scss">
#login{
  position: relative;
  background:#2a2a2a;
  color: #ffffff;
  height: 347px;
}
  .frame{
    width: auto;
    height: auto;
  }
  .login{
    width: 400px;
    height: 200px;
    border: 1px solid black;
    border-radius: 5%;
    position: absolute;
    top: 73px; /* (347 - 200) / 2 */
    left: 200px;
  }
  .next{
    height: 30px;
    width: 50px;
    font-size:50px;
    /* padding: 10px; */
    left: 700px;
    top: 280px;
  }
</style>
